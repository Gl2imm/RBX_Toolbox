import os
import sys
import urllib.request
import zipfile
import subprocess
import bpy
import shutil  # New: For deleting old add-on files

# GitHub ZIP URL (Replace with your actual repo link)
UPDATE_URL = "https://github.com/Gl2imm/RBX_Toolbox/releases/download/v.4.7/RBX_Toolbox_v.4.7.zip"
#https://drive.google.com/file/d/1vBTCPuv1z0UOuzEMikCe_hOy4tu9_j6O/view?usp=sharing

# Global flag to track update status
update_installed = False

def download_and_install_update():
    """Download and install the update from GitHub"""
    global update_installed
    addon_path = os.path.dirname(os.path.abspath(__file__))
    download_path = os.path.join(addon_path, "update.zip")

    try:
        print("Downloading update...")
        urllib.request.urlretrieve(UPDATE_URL, download_path)

        # 🔥 New: Delete old add-on files (except __init__.py to prevent crashes)
        for filename in os.listdir(addon_path):
            file_path = os.path.join(addon_path, filename)
            #if os.path.isfile(file_path) and filename != "__init__.py" and filename != "update.zip":
            if os.path.isfile(file_path) and filename != "update.zip":
                os.remove(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)

        # Extract ZIP
        with zipfile.ZipFile(download_path, 'r') as zip_ref:
            zip_ref.extractall(addon_path)

        # Cleanup
        os.remove(download_path)

        # Mark update as installed
        update_installed = True
        print("Update Installed! Reloading Add-on.")
        #reload_addon()  # 🔄 Automatically reload the add-on!
        return True
    except Exception as e:
        print(f"Update Failed: {str(e)}")
        return False

'''def reload_addon():
    """Reloads the add-on without restarting Blender"""
    addon_name = os.path.basename(os.path.dirname(__file__))
    bpy.ops.preferences.addon_disable(module=addon_name)
    bpy.ops.preferences.addon_enable(module=addon_name)'''

def restart_blender():
    """Restart Blender"""
    blender_exe = sys.argv[0]  # Get the Blender executable path
    subprocess.Popen([blender_exe])
    bpy.ops.wm.quit_blender()

# Operators for UI Buttons
class INSTALL_UPDATE_OT_Operator(bpy.types.Operator):
    """Download and Install Update"""
    bl_idname = "wm.install_update"
    bl_label = "Install Update"

    def execute(self, context):
        if download_and_install_update():
            self.report({'INFO'}, "Update Installed! Reloading Add-on.")
        else:
            self.report({'ERROR'}, "Update Failed!")
        return {'FINISHED'}

class RESTART_BLENDER_OT_Operator(bpy.types.Operator):
    """Restart Blender"""
    bl_idname = "wm.restart_blender"
    bl_label = "Restart Blender"

    def execute(self, context):
        restart_blender()
        return {'FINISHED'}

